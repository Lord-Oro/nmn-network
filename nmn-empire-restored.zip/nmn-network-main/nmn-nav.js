/* nmn-nav.js — NMN Global Controller v2.0
   GA4 · Favicon · Lantern Cursor · Lang Switcher
   Include as FIRST script in <body> on every page */

// 1. GA4
(function(){
  if(document.querySelector('script[src*="G-P5WL9XNDY8"]'))return;
  var s=document.createElement('script');s.async=true;
  s.src='https://www.googletagmanager.com/gtag/js?id=G-P5WL9XNDY8';
  document.head.appendChild(s);
  window.dataLayer=window.dataLayer||[];
  function gtag(){dataLayer.push(arguments);}
  window.gtag=gtag;gtag('js',new Date());gtag('config','G-P5WL9XNDY8');
})();

// 2. FAVICON
(function(){
  if(document.querySelector('link[rel="icon"]'))return;
  var depth=(window.location.pathname.split('/').filter(Boolean).length>1)?'../':'';
  var l=document.createElement('link');
  l.rel='icon';l.type='image/jpeg';l.href=depth+'lord_oro_emblem.jpg';
  document.head.appendChild(l);
})();

// 3. LANTERN CURSOR
(function(){
  if(document.getElementById('nmn-cursor-el'))return;
  var css=document.createElement('style');
  css.id='nmn-global-cursor';
  css.textContent='body,*{cursor:none!important}#nmn-cursor-el{position:fixed;width:48px;height:64px;pointer-events:none;z-index:99999;transform:translate(-50%,-50%);left:-200px;top:-200px}#nmn-halo{position:fixed;width:140px;height:140px;pointer-events:none;z-index:99998;transform:translate(-50%,-50%);border-radius:50%;background:radial-gradient(circle,rgba(255,200,50,.09) 0%,transparent 65%);left:-200px;top:-200px}#nmn-pool{position:fixed;width:180px;height:60px;pointer-events:none;z-index:99997;transform:translate(-50%,22px);border-radius:50%;background:radial-gradient(ellipse,rgba(255,200,50,.06) 0%,transparent 70%);left:-200px;top:-200px}.l-body{animation:nmn-sway 3s ease-in-out infinite;transform-origin:24px 4px}.l-flame{animation:nmn-flame 1.6s ease-in-out infinite}.l-glow{animation:nmn-glow 1.6s ease-in-out infinite}@keyframes nmn-sway{0%,100%{transform:rotate(-2deg)}50%{transform:rotate(2deg)}}@keyframes nmn-flame{0%,100%{transform:scaleY(1);opacity:.9}50%{transform:scaleY(.85);opacity:.7}}@keyframes nmn-glow{0%,100%{opacity:.5}50%{opacity:.3}}';
  document.head.appendChild(css);
  var markup='<div id="nmn-pool"></div><div id="nmn-halo"></div><div id="nmn-cursor-el"><svg viewBox="0 0 48 64" width="48" height="64" xmlns="http://www.w3.org/2000/svg"><g class="l-body"><rect x="22" y="0" width="4" height="3" fill="#6a5a30" rx="1"/><rect x="23" y="3" width="2" height="5" fill="#8B6914"/><rect x="14" y="8" width="20" height="3" fill="#8B6914" rx="1"/><rect x="17" y="11" width="14" height="2" fill="#B8860B"/><rect x="14" y="13" width="3" height="26" fill="#8B6914"/><rect x="31" y="13" width="3" height="26" fill="#8B6914"/><rect x="17" y="13" width="14" height="26" fill="#1a1000" opacity="0.5"/><rect class="l-glow" x="17" y="13" width="14" height="26" fill="#FFD700" opacity="0.4" rx="1"/><g class="l-flame"><ellipse cx="24" cy="26" rx="5" ry="7" fill="#FF8C00" opacity="0.9"/><ellipse cx="24" cy="27" rx="3.5" ry="5" fill="#FFD700"/><ellipse cx="24" cy="28" rx="2" ry="3" fill="#FFFAAA"/></g><rect x="14" y="39" width="20" height="3" fill="#8B6914" rx="1"/><rect x="19" y="44" width="10" height="3" fill="#8B6914" rx="1"/></g></svg></div>';
  function boot(){
    document.querySelectorAll('style[id*="cursor"],style[id*="nmn-cursor-inject"]').forEach(function(s){s.remove();});
    document.body.insertAdjacentHTML('afterbegin',markup);
    var CE=document.getElementById('nmn-cursor-el');
    var HA=document.getElementById('nmn-halo');
    var PO=document.getElementById('nmn-pool');
    document.addEventListener('mousemove',function(e){
      CE.style.left=e.clientX+'px';CE.style.top=e.clientY+'px';
      HA.style.left=e.clientX+'px';HA.style.top=e.clientY+'px';
      PO.style.left=e.clientX+'px';PO.style.top=e.clientY+'px';
    });
    document.querySelectorAll('a,button,.btn,.work-card').forEach(function(el){
      el.addEventListener('mouseenter',function(){CE.style.filter='drop-shadow(0 0 10px #FFD700)';});
      el.addEventListener('mouseleave',function(){CE.style.filter='';});
    });
  }
  if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',boot);}else{boot();}
})();

// 4. LANG SWITCHER
window.NMN_LANGS={en:{flag:'🇺🇸',label:'EN',title:'The goldmine',em:'is within.'},ko:{flag:'🇰🇷',label:'한',title:'금광은',em:'내 안에 있다.'},es:{flag:'🇵🇷',label:'ES',title:'La mina de oro',em:'está dentro.'},ja:{flag:'🇯🇵',label:'JP',title:'金鉱は',em:'内にある。'},de:{flag:'🇩🇪',label:'DE',title:'Die Goldmine',em:'ist innen.'},fr:{flag:'🇫🇷',label:'FR',title:"La mine d'or",em:'est en vous.'}};
window.setLang=function(l){var d=window.NMN_LANGS[l];if(!d)return;var b=document.getElementById('langBtn');if(b)b.textContent=d.flag+' '+d.label;var t=document.querySelector('.hero-title');if(t){var tn=Array.from(t.childNodes).find(function(n){return n.nodeType===3;});if(tn)tn.textContent=d.title+' ';var em=t.querySelector('em');if(em)em.textContent=d.em;}try{localStorage.setItem('nmn_lang',l);}catch(e){}var m=document.getElementById('langMenu');if(m)m.classList.remove('open');if(l!=='en'&&typeof launchLesson==='function')launchLesson(l);};
window.toggleLang=function(){var m=document.getElementById('langMenu');if(m)m.classList.toggle('open');};
document.addEventListener('click',function(e){if(e.target.closest&&!e.target.closest('.lang-switcher')){var m=document.getElementById('langMenu');if(m)m.classList.remove('open');}});
window.addEventListener('DOMContentLoaded',function(){try{var s=localStorage.getItem('nmn_lang');if(s&&s!=='en')setTimeout(function(){setLang(s);},100);}catch(e){}});
